/*
 * des_cpu.h
 *
 *  Created on: 11 lis 2018
 *      Author: tomasz
 */

#ifndef DES_CPU_H_
#define DES_CPU_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "constants.h"

void desCPU(uint64_t input, uint64_t key, char mode, uint64_t *result);
void desCPU2(uint64_t input, uint64_t key, char mode, uint64_t *result);
uint64_t encryptCPU(uint64_t input, uint64_t key);
uint64_t decryptCPU(uint64_t input, uint64_t key);

#endif /* DES_CPU_H_ */
