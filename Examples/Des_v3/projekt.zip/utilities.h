#pragma once
#include <stdio.h>
#include <cmath>

#include "cuda_runtime.h"
#include "device_launch_parameters.h"

void CudaMalloc(void **dest, size_t size)
{
	cudaError_t cudaStatus = cudaMalloc(dest, size);
	if (cudaStatus != cudaSuccess)
	{
		printf("%s\n", "cudaMalloc failed!");
		printf("%s\n", cudaGetErrorString(cudaStatus));
	    exit(EXIT_FAILURE);
	}
}

void CudaMemset(void *dest, int val, size_t size)
{
	cudaError_t cudaStatus = cudaMemset(dest, val, size);
	if (cudaStatus != cudaSuccess)
	{
		printf("%s\n", "cudaMemset failed!");
		printf("%s\n", cudaGetErrorString(cudaStatus));
	    exit(EXIT_FAILURE);
	}
}

void CudaMemcpy(void *dest, const void *src, size_t size, cudaMemcpyKind kind)
{
	cudaError_t cudaStatus = cudaMemcpy(dest, src, size, kind);
	if (cudaStatus != cudaSuccess)
	{
		printf("%s\n", "cudaMemcpy failed!");
		printf("%s\n", cudaGetErrorString(cudaStatus));
	    exit(EXIT_FAILURE);
	}
}
