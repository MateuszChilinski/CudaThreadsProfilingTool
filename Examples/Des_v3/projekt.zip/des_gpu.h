/*
 * des_gpu.h
 *
 *  Created on: 17 lis 2018
 *      Author: tomasz
 */

#ifndef DES_GPU_H_
#define DES_GPU_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define DeviceToHost cudaMemcpyDeviceToHost
#define HostToDevice cudaMemcpyHostToDevice

__global__ void desGPU(uint64_t *input, uint64_t *key, char mode, uint64_t *result);
__global__ void desGPU2(uint64_t *input, uint64_t *expected, uint64_t *startKey, uint64_t *endKey, volatile bool *done);
__global__ void desGPU2encrypt(uint64_t *input, uint64_t *expected, uint64_t *startKey, uint64_t *endKey, volatile bool *done, uint64_t *found);

#endif /* DES_GPU_H_ */
