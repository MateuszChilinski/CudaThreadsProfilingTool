#include "des_cpu.h"

void permBits(uint64_t input, uint64_t *output, char *table, int N)
{
	*output = 0;
	for (int i = 0; i < N; i++)
	{
		*output <<= 1;
		*output |= (input >> (64-table[i])) & 0x0000000000000001;
	}
}

void permBits(uint32_t input, uint64_t *output, char *table, int N)
{
	*output = 0;
	for (int i = 0; i < N; i++)
	{
		*output <<= 1;
		*output |= (uint64_t) ((input >> (32-table[i])) & 0x00000001);
	}
}

void permBits(uint32_t input, uint32_t *output, char *table, int N)
{
	*output = 0;
	for (int i = 0; i < N; i++)
	{
		*output <<= 1;
		*output |= ((input >> (32-table[i])) & 0x00000001);
	}
}

void calculateSubkeys(uint32_t C, uint32_t D, uint64_t *subKeys)
{
	for (int i = 0; i< 16; i++)
	{
		/* key schedule */
		// shifting Ci and Di
		for (int j = 0; j < iteration_shift[i]; j++)
		{
			C = (0x0fffffff & (C << 1)) | (0x00000001 & (C >> 27));
			D = (0x0fffffff & (D << 1)) | (0x00000001 & (D >> 27));
		}
		uint64_t permuted = (((uint64_t) C) << 28) | (uint64_t) D ;

		subKeys[i] = 0;
		for (int j = 0; j < 48; j++)
		{
			subKeys[i] <<= 1;
			subKeys[i] |= (permuted >> (56-PC2[j])) & 0x0000000000000001;
		}
	}
}

void calculateF(uint32_t R, uint64_t subKey, uint32_t *result)
{
    char row, column;
	uint64_t preSBox;
	uint32_t postSBox;

	permBits(R, &preSBox, E, 48);
	preSBox = preSBox ^ subKey;

	// Wykorzystuję S-Boxy
	for (int i = 0; i < 8; i++)
	{
		// 00 00 RCCC CR00 00 00 00 00 00 preSBox
		// 00 00 1000 0100 00 00 00 00 00 row mask
		// 00 00 0111 1000 00 00 00 00 00 column mask

		row = (char) ((preSBox & (0x0000840000000000 >> 6*i)) >> 42-6*i);
		row = (row >> 4) | (row & 0x01);

		column = (char) ((preSBox & (0x0000780000000000 >> 6*i)) >> 43-6*i);

		postSBox <<= 4;
		postSBox |= (uint32_t) (S[i][16*row + column] & 0x0f);
	}
	permBits(postSBox, result, P, 32);
}

void desCPU(uint64_t input, uint64_t key, char mode, uint64_t *result)
{
    // 48 bitowe podklucze
    uint64_t subKey[16] = {0};

    // WSTĘPNE PRZYGOTOWANIE KLUCZA
    // Permutacja PC-1 - dostaję 56-bitowy klucz i dzielę go na 2 połówki
	permBits(key, &key, PC1, 56);
	uint32_t C = (uint32_t) ((key >> 28) & 0x000000000fffffff);
	uint32_t D = (uint32_t) (key & 0x000000000fffffff);
    // Na podstawie połówek wyznaczam 16 podkluczy
    calculateSubkeys(C, D, subKey);

    // GŁÓWNA CZĘŚĆ ALGORYTMU
    // Poddaję dane wstępnej permutacji
	permBits(input, &input, IP, 64);
	// Dzielę dane po permutacji na 2 połówki
    uint32_t L = (uint32_t) (input >> 32) & 0x00000000ffffffff;
    uint32_t R = (uint32_t) input & 0x00000000ffffffff;

    // Stosuję każdy z podkluczy do połówek danych
    for (int i = 0; i < 16; i++)
    {
    	uint32_t fResult;
    	// Stosuję magiczną funkcję f. Kolejność stosowania podkluczy zależna czy szyfruję czy rozszyfrowuję
        if (mode == 'd')
            calculateF(R, subKey[15-i], &fResult);
        else
            calculateF(R, subKey[i], &fResult);

        // L zmienia się w R, a R jest wynikiem L XOR f(R, K)
        uint32_t temp = R;
        R = L ^ fResult;
        L = temp;
    }
    // Sklejam L i R (w kolejności RL)
    *result = (((uint64_t) R) << 32) | (uint64_t) L;

    // Stosuję permutację odwrotną (IP^-1)
    permBits(*result, result, PI, 64);
}

void desCPU2(uint64_t input, uint64_t key, char mode, uint64_t *result)
{
    // 48 bitowe podklucze
    uint64_t subKey[16] = {0};

    // WSTĘPNE PRZYGOTOWANIE KLUCZA
    // Dzielę klucz na 2 połówki
	uint32_t C = (uint32_t) ((key >> 28) & 0x000000000fffffff);
	uint32_t D = (uint32_t) (key & 0x000000000fffffff);
    // Na podstawie połówek wyznaczam 16 podkluczy
    calculateSubkeys(C, D, subKey);

    // GŁÓWNA CZĘŚĆ ALGORYTMU
    // Poddaję dane wstępnej permutacji
	permBits(input, &input, IP, 64);
	// Dzielę dane po permutacji na 2 połówki
    uint32_t L = (uint32_t) (input >> 32) & 0x00000000ffffffff;
    uint32_t R = (uint32_t) input & 0x00000000ffffffff;

    // Stosuję każdy z podkluczy do połówek danych
    for (int i = 0; i < 16; i++)
    {
    	uint32_t fResult;
    	// Stosuję magiczną funkcję f. Kolejność stosowania podkluczy zależna czy szyfruję czy rozszyfrowuję
        if (mode == 'd')
            calculateF(R, subKey[15-i], &fResult);
        else
            calculateF(R, subKey[i], &fResult);

        // L zmienia się w R, a R jest wynikiem L XOR f(R, K)
        uint32_t temp = R;
        R = L ^ fResult;
        L = temp;
    }
    // Sklejam L i R (w kolejności RL)
    *result = (((uint64_t) R) << 32) | (uint64_t) L;

    // Stosuję permutację odwrotną (IP^-1)
    permBits(*result, result, PI, 64);
}

inline uint64_t encryptCPU(uint64_t input, uint64_t key)
{
	uint64_t result;
	desCPU(input, key, 'e', &result);
	return result;
}

inline uint64_t decryptCPU(uint64_t input, uint64_t key)
{
	uint64_t result;
	desCPU(input, key, 'e', &result);
	return result;
}
